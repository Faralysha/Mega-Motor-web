<?php

$conn = mysqli_connect('localhost','root','','shopberjaya') or die('connection failed');

?>